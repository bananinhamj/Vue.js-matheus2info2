<script>
export default {};
</script>
<template>
  <aside id="sidenav">
    <p class="lateral">Carros</p>
    <p class="lateral">Cadeiras</p>
    <p class="lateral">Mesas</p>
    <p class="lateral">Portas</p>
    <p class="lateral">Janelas</p>
    <p class="lateral">Plantas</p>
    <p class="lateral">Tapetes</p>
  </aside>
</template>
<style></style>
