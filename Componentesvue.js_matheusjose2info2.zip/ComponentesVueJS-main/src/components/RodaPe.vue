<script>
export default {};
</script>
<template>
  <footer id="footer">
      <p>Feito por Raphael Otto 2 Info 2</p>
  </footer>
</template>
<style></style>
