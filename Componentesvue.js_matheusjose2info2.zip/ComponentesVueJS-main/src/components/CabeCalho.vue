<script>
export default {};
</script>
<template>
  <header id="header">
      <h1 class="titulo">Mercado Preso</h1>
  </header>
</template>
<style></style>
