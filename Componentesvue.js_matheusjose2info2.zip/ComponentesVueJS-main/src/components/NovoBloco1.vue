<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/celta.jpg" />
    <p>Celta</p>
  </article>
</template>
<style></style>
