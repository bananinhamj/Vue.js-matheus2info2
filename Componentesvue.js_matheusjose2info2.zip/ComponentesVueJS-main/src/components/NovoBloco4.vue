<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/porta.jpg" />
    <p>Porta</p>
  </article>
</template>
<style></style>
