<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/cadeira.jpg" />
    <p>Cadeira de Madeira</p>
  </article>
</template>
<style></style>
