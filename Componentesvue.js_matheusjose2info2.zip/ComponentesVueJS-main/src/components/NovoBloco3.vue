<script>
export default {};
</script>
<template>
  <article class="block">
    <img src="@/assets/img/tapete.jpg" />
    <p>Tapete de Urso</p>
  </article>
</template>
<style></style>
